import { NextResponse } from "next/server";
import { Mistral } from "@mistralai/mistralai";
import { CHARACTERS } from "@/data/characters";

const client = new Mistral({
  apiKey: process.env.MISTRAL_API_KEY,
});

export async function POST(req: Request) {
  try {
    const { messages, characterId } = await req.json();
    const character = CHARACTERS.find((c) => c.id === characterId);

    if (!character) {
      return NextResponse.json(
        { error: "Karakter tidak ditemukan" },
        { status: 404 }
      );
    }

    const formattedMessages: Array<{
      role: "system" | "user" | "assistant";
      content: string;
    }> = [
      {
        role: "system",
        content: character.systemPrompt,
      },
      ...messages.map((msg: { role: string; content: string }) => ({
        role: msg.role === "user" ? ("user" as const) : ("assistant" as const),
        content: msg.content,
      })),
    ];

    const chatResponse = await client.chat.complete({
      model: "mistral-small-latest",
      messages: formattedMessages,
      temperature: 0.85,
    });

    const rawContent = chatResponse.choices?.[0]?.message?.content;
    const reply =
      typeof rawContent === "string"
        ? rawContent
        : Array.isArray(rawContent)
        ? rawContent
            .map((chunk) =>
              "text" in chunk && typeof chunk.text === "string" ? chunk.text : ""
            )
            .join("")
        : "";

    return NextResponse.json({ reply });
  } catch (error) {
    console.error("Mistral Chat API Error:", error);
    return NextResponse.json(
      { error: "Gagal memproses pesan dengan Mistral AI" },
      { status: 500 }
    );
  }
}
